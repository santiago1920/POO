package poo.unicauca.edu.co;
public class e1 {
    public String firstName = "Santiago";
    public String lastName= "Rodriguez";
}
